# WDM Media — Single-File Editorial Social Platform

WDM Media is a complete, original social networking platform engineered so the entire frontend lives inside a single standalone HTML document (`media.html`) connected directly to your existing Firebase (`wdm-update`) and Cloudinary (`afcw94ij`) infrastructure. Alongside the single-file frontend, hardened Firestore security rules, composite index definitions, and a trusted Firebase Cloud Functions backend specification ensure production-grade data integrity without exposing private credentials on the client.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Because clarifying questions were skipped, the plan proceeds with the recommended defaults below. You can request changes to any choice before implementation begins.

- **Visual Theme & Editorial Direction (Recommended Default)**: **Editorial Ink & Paper** — warm paper-white light theme and deep obsidian dark theme with a crisp electric cobalt interactive accent, `Fraunces` editorial serif wordmark/headings paired with `Plus Jakarta Sans` UI typography and `JetBrains Mono` tabular counters.
- **Unauthenticated Entry Experience (Recommended Default)**: **Split-screen editorial auth portal** featuring WDM Media branding, live light/dark preview toggle, Email/Password sign-in, Google Sign-In, registration with real-time username availability & reservation, and password reset.
- **Backend Configuration Artifacts (Recommended Default)**: Alongside the strictly single-file `media.html` frontend (no separate CSS or JS frontend files), we will provide separate deployable backend configuration artifacts covering hardened Firestore Security Rules, composite query indexes, and trusted Firebase Cloud Functions (for server-authoritative counters, notifications, scheduled 24-hour story cleanup, and signed Cloudinary deletion).
- **Live Workspace Preview (Recommended Default)**: The workspace root automatically launches `media.html` so you can immediately preview and test the exact single-file deliverable while keeping `media.html` 100% self-contained for direct GitHub deployment.
- **Strict Reels Exclusion**: WDM Media will contain zero Reels tabs, pages, uploads, or short-video vertical scrollers. Standard videos remain supported in regular posts, stories, and direct messages.

---

## 1. Overview & Core Concept

- **What It Does**: Delivers a complete social media platform in one portable HTML5 file (`media.html`) featuring authentication, customizable public/private profiles, multi-photo and standard video publishing, a three-mode editorial Home Feed (`For You`, `Following`, `Latest`), ephemeral 24-hour Stories, real-time 1:1 Direct Messaging with media attachments and presence indicators, a Notification Center, Explore & debounced Search, Saved Post Collections, and comprehensive Account & Theme Settings.
- **Target Audience / Persona**: Independent creators, photographers, writers, and communities seeking a calm, publication-grade social experience free of algorithmic short-video clutter, built on an inspectable, zero-build-step codebase.
- **Key Value**: Combines magazine-caliber editorial presentation with real Firebase Authentication, Cloud Firestore real-time synchronization, and Cloudinary direct media uploads—all maintained cleanly in a single deployable file with honest separation between client operations and trusted Cloud Functions.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Onboarding & Identity Reservation**:
   - Unauthenticated visitors land on the split-screen Editorial Auth Portal.
   - Users register with email/password (or sign in via Google), receive email verification prompts, and claim a unique lowercase `@username` validated in real time against Firestore (`usernames/{handle}`) via an atomic transaction that simultaneously initializes `users/{uid}` and default `users/{uid}/settings/preferences`.
   - Returning users restore sessions automatically via Firebase persistent auth.
2. **Editorial Home Feed & Stories**:
   - At the top of the central editorial column sits a crisp horizontal Stories tray showing active (<24h) stories from followed creators and the signed-in user's `+ Add Story` trigger. Clicking opens an uncluttered full-screen Story Viewer with segmented progress bars, keyboard/tap navigation, emoji reactions, direct reply composer, privacy badges (Public / Followers / Close Friends), and owner-only viewer lists & deletion.
   - Below Stories, a clean segmented control switches between `For You` (scored by follow affinity, saved/liked hashtag interests, engagement signals, freshness decay, and creator diversity), `Following` (chronological followed creators), and `Latest` (global public timeline), with cursor-based pagination, infinite scroll sentinel, duplicate ID deduplication, skeleton loaders, and clear empty states.
3. **Publishing & Media Workflow**:
   - Clicking `Create Post` opens a clean publishing modal supporting single images, multi-image carousels (with reorder/remove previews), and standard videos (`mp4`/`webm`/`mov`), plus caption input with automatic `#hashtag` and `@mention` parsing and optional location.
   - Files undergo strict client-side MIME type and size validation, instant local preview, real-time XMLHttpRequest upload progress bar to Cloudinary (`afcw94ij` / `wdm_media`), and automatic delivery URL optimization (`f_auto,q_auto`) before writing metadata to `posts/{postId}`.
4. **Profiles, Relationships & Privacy**:
   - Visiting any profile displays cover photography, avatar, display name, `@handle`, bio, website, location, and clean tabular counts (Posts · Followers · Following) without pill clutter.
   - Supports instant Follow/Unfollow for public profiles, Follow Request submission + Accept/Reject queue for private accounts, modal Followers/Following lists, Share Profile (copy link / Web Share), Block/Unblock, Report User, and full Profile Editor with Cloudinary avatar/cover upload.
   - Private profiles restrict posts and stories to approved followers and the account owner.
5. **Real-Time Messaging**:
   - Split-pane conversation layout on desktop (searchable thread list + active chat pane) and responsive list-to-thread transition on mobile.
   - Supports real-time text, Cloudinary image/video attachments, message reply quotes, emoji reactions, inline editing, soft deletion (`"Message deleted"`), delivered/read status indicators, live typing indicators, online/last-seen presence, unread counters, in-chat message search, and user block/report controls.
6. **Discovery, Saved Collections, Notifications & Settings**:
   - **Search & Explore**: Debounced live search across users, posts, and hashtags; recent searches; live suggestions; trending topics; recommended accounts; and a media-first Bento/masonry Explore grid.
   - **Saved Posts**: Bookmark any post directly or organize into private named collections (create, rename, delete collections).
   - **Notifications**: Header dropdown + dedicated Notification Center view with unread badge, mark-as-read, mark-all-as-read, and categorized history. Clearly surfaces backend Cloud Function status for cross-user notifications rather than allowing insecure client-side spoofing.
   - **Settings**: Light/Dark/System theme switcher, privacy toggle (Public/Private account), notification preferences, blocked accounts list with unblock action, email verification resend, and password reset.

### Visual Identity & Theme

- **Aesthetic Direction**: **Editorial Ink & Paper** — inspired by independent photography monographs and print broadsheets. Quiet neutral canvases let user photography and video carry the visual energy, anchored by generous whitespace, 1px hairline borders, and disciplined single-elevation surfaces.
- **Color Palette & CSS Custom Properties** (60-30-10 discipline, complete Light/Dark parity without `!important` inversion hacks):
  - *Light Mode (`:root`)*:
    - `--bg-canvas: #F8F8F6` (60% warm paper canvas)
    - `--bg-surface: #FFFFFF` & `--bg-subtle: #F1F1EE` (30% structural cards & inputs)
    - `--border-hairline: #E5E5E0`
    - `--text-primary: #111214` & `--text-secondary: #5A5E66`
    - `--accent: #1D4ED8` & `--accent-hover: #1E40AF` (10% primary CTAs, active tabs, focus rings)
    - `--danger: #DC2626`, `--success: #15803D`, `--warning: #B45309` (always paired with text/icons)
  - *Dark Mode (`[data-theme="dark"]`)*:
    - `--bg-canvas: #0B0C0E` (60% deep obsidian)
    - `--bg-surface: #131519` & `--bg-subtle: #1B1E24` (30% structural surfaces, ≤12% delta)
    - `--border-hairline: #242830`
    - `--text-primary: #F2F4F7` & `--text-secondary: #98A0AE` (optical weight/tracking compensation)
    - `--accent: #4F86FF` & `--accent-hover: #709DFF`
- **Typography & Hierarchy** (2+1 font system via Google Fonts CDN):
  - *Display & Editorial Brand*: `Fraunces` (600–700, `text-wrap: balance`, tight tracking) for the WDM Media wordmark, auth hero headline, and editorial view titles.
  - *Interface & Body*: `Plus Jakarta Sans` (400 Regular, 600 SemiBold; 15px body at 1.6 line-height, 13px muted metadata).
  - *Tabular Metrics & Timestamps*: `JetBrains Mono` (`font-variant-numeric: tabular-nums`) for follower counts, engagement numbers, upload percentages, and timestamps.
- **Component Styling & Layout**:
  - *Desktop (1440px baseline)*: Full-width editorial three-column shell (`240px` sticky left navigation rail with Home, Search, Explore, Notifications, Messages, Create Post, Profile, Settings · `minmax(0, 680px)` central editorial stream · `320px` right rail for Search quick-bar, Trending Topics, and Recommended Accounts).
  - *Mobile (375px–430px)*: Compact `52px` sticky top bar (WDM wordmark, Search icon, Messages shortcut with unread count) + `58px` fixed bottom 5-tab bar (Home, Explore, Create, Notifications, Profile) — keeping combined sticky height strictly under 15% of viewport height with minimum `44px × 44px` touch targets.
  - *Zero-Pill Discipline*: Timestamps, locations, post metrics, and hashtags appear as clean unboxed typography with `·` separators rather than rounded pill chips; interactive feed/profile tabs use clean segmented controls or crisp bottom indicator lines.

### Interactive Feedback & Motion

- Routine hover/focus/active transitions settle within `150ms` using `cubic-bezier(0.16, 1, 0.3, 1)` on compositor-only properties (`transform`, `opacity`).
- Skeleton shimmer placeholders during Firestore queries, inline upload progress bars during Cloudinary transfers, toast notifications for every mutation (save, copy link, post published, error details), graceful media fallbacks for any broken image, and full `prefers-reduced-motion` support.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Strict Single-File Frontend Architecture (`media.html`)**
  - *Chosen Approach*: Consolidate 100% of HTML markup, CSS custom properties & responsive rules (`<style>`), and modular ES JavaScript (`<script type="module">`) inside one well-sectioned `media.html` file importing Firebase v11 modular SDK and Lucide icons via CDN.
  - *Why*: Meets the strict single-file GitHub deployment requirement with zero build tooling required to run or host `media.html` anywhere.
  - *Alternatives Considered*: Bundling React/Tailwind via Vite — rejected because it violates the strict single-file vanilla JS constraint.

- **Decision 2: Honest Client vs. Trusted Backend Separation**
  - *Chosen Approach*: Execute user-owned writes directly from `media.html` where Firestore rules safely permit them (creating posts, liking via `posts/{postId}/likes/{uid}`, commenting, following via `follows/{followerId_followingId}`, sending authorized chat messages, saving posts, submitting reports). Rely on documented, ready-to-deploy Firebase Cloud Functions for privileged operations (incrementing aggregate counters, creating cross-user notifications, 24h story expiry cleanup, and signed Cloudinary asset deletion) while rendering optimistic local UI updates so interactions feel instantaneous without ever weakening Firestore security rules.
  - *Why*: Never exposes Admin SDK or Cloudinary API secrets in `media.html`, prevents counter tampering or notification spam from arbitrary clients, and remains completely transparent about what requires Cloud Functions deployment.
  - *Alternatives Considered*: Letting the client increment counters or write arbitrary notifications — rejected as a critical security vulnerability.

- **Decision 3: Practical Client-Side Recommendation Scoring + Subcollection Scalability**
  - *Chosen Approach*: Store likes, comments, story viewers/reactions, saved posts, and chat messages strictly in subcollections or edge collections (never unbounded arrays on parent documents). Compute `For You` feed rankings by scoring fetched candidate posts across follow affinity, matched user-interest hashtags, engagement ratios, exponential time decay, and creator diversity throttling, while keeping pagination cursors and duplicate-ID guards clean.
  - *Why*: Avoids Firestore 1MB document limits and write contention while delivering genuine personalized ordering immediately on the client and supporting future backend ranking jobs seamlessly.

- **Decision 4: Real-Time Listener Lifecycle Registry**
  - *Chosen Approach*: Centralize all Firestore `onSnapshot` unsubscribe callbacks in a view-scoped listener registry (`activeListeners`) alongside a persistent auth-scoped listener group (current user profile, unread notifications, unread chats). Whenever navigation switches views or a user logs out, view-scoped listeners are torn down automatically.
  - *Why*: Eliminates memory leaks, duplicate DOM updates, and wasted Firestore read quotas.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### System Architecture & Internal Single-File Flow

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                        media.html (Single-File Frontend)                     │
│  ┌──────────────────────┐  ┌──────────────────────────────────────────────┐  │
│  │  <style> Design Sys  │  │  <script type="module"> Application Engine   │  │
│  │  • Theme CSS Tokens  │  │  • Singleton Firebase App (wdm-update)       │  │
│  │  • Desktop 3-Col App │  │  • Cloudinary Unsigned Uploader (afcw94ij)   │  │
│  │  • Mobile Thumb Nav  │  │  • Central Store + Listener Cleanup Registry │  │
│  │  • Modals & Lightbox │  │  • Modular Feature Controllers (Sections 6-18│  │
│  └──────────────────────┘  └──────────────────────┬───────────────────────┘  │
└───────────────────────────────────────────────────┼──────────────────────────┘
                                                    │
         ┌──────────────────────────────────────────┴──────────────────────────────────┐
         ▼                                          ▼                                  ▼
┌─────────────────────┐                ┌──────────────────────────┐        ┌────────────────────────┐
│   Firebase Auth     │                │     Cloud Firestore      │        │    Cloudinary API      │
│ • Email/Password    │                │ • users & settings       │        │ • /v1_1/afcw94ij/      │
│ • Google OAuth      │                │ • usernames (unique lock)│        │   auto/upload          │
│ • Verification      │                │ • posts (+likes,comments)│        │ • Preset: wdm_media    │
│ • Password Reset    │                │ • stories (+views,reacts)│        │ • f_auto,q_auto URLs   │
│ • Local Persistence │                │ • follows/followRequests │        │ • Client MIME/Size Val │
└─────────────────────┘                │ • chats (+messages)      │        └────────────────────────┘
                                       │ • notifications (RO*)    │                     ▲
                                       │ • savedPosts & reports   │                     │
                                       └────────────┬─────────────┘                     │
                                                    │                                   │
                                       ┌────────────▼───────────────────────────────────┴──┐
                                       │   Separate Backend Deployment Artifacts           │
                                       │ • Hardened Firestore Rules & Composite Indexes    │
                                       │ • Cloud Functions (Counters, Notifications,       │
                                       │   24h Story Cleanup, Signed Cloudinary Deletion)  │
                                       └───────────────────────────────────────────────────┘
```

### Data Model & Collections

- **Identity & Settings**:
  - `users/{uid}`: profile fields (`username`, `displayName`, `bio`, `website`, `location`, `photoURL`, `coverURL`, `isPrivate`, `interests`, `online`, `lastSeen`, `createdAt`) plus backend-maintained counts (`followersCount`, `followingCount`, `postsCount`).
  - `usernames/{handle}`: atomic uniqueness lock mapping lowercase handle → `uid`.
  - `users/{uid}/settings/{settingId}`: theme preference, notification toggles, privacy preferences.
  - `users/{uid}/savedPosts/{postId}` & `users/{uid}/collections/{collectionId}`: private bookmarks and custom collections.
  - `users/{uid}/blocked/{targetUid}`: private block list enforced across feed, profiles, and chat.
- **Social Graph**:
  - `follows/{followerId_followingId}`: validated follow edge (`followerId`, `followingId`, `createdAt`).
  - `followRequests/{followerId_followingId}`: pending private-account request (`followerId`, `followingId`, `status`, `createdAt`).
- **Content & Ephemeral Stories**:
  - `posts/{postId}`: `authorId`, `media[]` (type, url, publicId, width, height), `caption`, `hashtags[]`, `mentions[]`, `location`, `visibility`, `createdAt`, `updatedAt`, plus server-maintained counters. Subcollections: `posts/{postId}/likes/{uid}` and `posts/{postId}/comments/{commentId}` (supporting `parentCommentId` for replies).
  - `stories/{storyId}`: `authorId`, `mediaType`, `mediaUrl`, `publicId`, `caption`, `privacy` (`public` | `followers` | `close_friends`), `createdAt`, `expiresAt`. Subcollections: `viewers/{uid}` and `reactions/{uid}`.
- **Communication, Alerts & Safety**:
  - `chats/{chatId}`: deterministic sorted pair ID (`uidA_uidB`), `members[]`, `lastMessage`, `lastMessageAt`, `unreadBy`, `typingBy`. Subcollection: `chats/{chatId}/messages/{messageId}` (text, media, `replyTo`, `reactions`, `editedAt`, `deleted`, `deliveredTo`, `readBy`).
  - `notifications/{notificationId}`: `recipientId`, `actorId`, `type`, `entityId`, `previewText`, `read`, `createdAt` (read/mark-read by recipient; created exclusively by Cloud Functions).
  - `reports/{reportId}`: write-only authenticated user reports (`reporterId`, `targetType`, `targetId`, `reason`, `details`, `createdAt`).

### Interactive Component & State Mapping

- **Auth Controller**: Validates inputs, checks username availability debounced (300ms), runs Firestore transaction to claim username + seed profile, maps Firebase error codes to plain-language banners.
- **Navigation & View Router**: Switches active view (`home`, `search`, `explore`, `notifications`, `messages`, `profile`, `saved`, `settings`), clears view-scoped Firestore listeners, updates desktop rail & mobile bottom tab active states, and scrolls cleanly to top.
- **Feed & Post Composer**: Handles multi-file selection, drag/drop, preview cards, XHR upload progress, hashtag/mention extraction, post creation/editing/deletion, optimistic like toggle synced with `posts/{postId}/likes/{uid}`, nested comment/reply drawer, save-to-collection popover, share modal, and report submission.
- **Story Engine**: Queries non-expired stories (`expiresAt > now`), groups by author, runs `requestAnimationFrame`/timer progress bar in the fullscreen viewer, logs view receipt to `stories/{id}/viewers/{uid}`, sends emoji reactions, routes story replies into `chats/{chatId}`, and exposes owner-only viewer list & delete action.
- **Messaging Engine**: Subscribes to member chats (`members array-contains uid`), opens real-time message stream for selected conversation, updates typing debounce & presence heartbeat, uploads image/video chat attachments via Cloudinary, supports inline edit/soft-delete/reply-quote/reactions, marks incoming messages read, and filters chats/messages live.
- **Security & Backend Artifacts**: Delivers audited `firestore.rules`, `firestore.indexes.json`, and a clearly documented `functions/` Cloud Functions backend implementation so every privileged counter, notification trigger, scheduled story cleanup, and Cloudinary signed delete can be deployed cleanly to `wdm-update`.
