/**
 * WDM Media — Trusted Firebase Cloud Functions (Backend Deployment Reference)
 * ---------------------------------------------------------------------------
 * Deploy separately via Firebase CLI (`firebase deploy --only functions`).
 * NEVER import or embed Admin SDK or Cloudinary API Secret inside media.html.
 *
 * Required secrets in Firebase Functions Secret Manager:
 *   CLOUDINARY_API_KEY
 *   CLOUDINARY_API_SECRET
 *   CLOUDINARY_CLOUD_NAME (afcw94ij)
 */

const { onDocumentCreated, onDocumentDeleted } = require('firebase-functions/v2/firestore');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const { defineSecret } = require('firebase-functions/params');
const admin = require('firebase-admin');
const crypto = require('crypto');

admin.initializeApp();
const db = admin.firestore();
const FieldValue = admin.firestore.FieldValue;

const cloudinaryApiKey = defineSecret('CLOUDINARY_API_KEY');
const cloudinaryApiSecret = defineSecret('CLOUDINARY_API_SECRET');
const CLOUDINARY_CLOUD_NAME = 'afcw94ij';

async function createNotification({ recipientId, actorId, type, entityId = '', previewText = '' }) {
  if (!recipientId || !actorId || recipientId === actorId) return;
  await db.collection('notifications').add({
    recipientId,
    actorId,
    type,
    entityId,
    previewText: String(previewText).slice(0, 140),
    read: false,
    createdAt: FieldValue.serverTimestamp(),
  });
}

// 1. Posts counter on user profile
exports.onPostCreated = onDocumentCreated('posts/{postId}', async (event) => {
  const data = event.data?.data();
  if (!data?.authorId) return;
  await db.doc(`users/${data.authorId}`).set({ postsCount: FieldValue.increment(1) }, { merge: true });

  // Notify mentioned users
  if (Array.isArray(data.mentions) && data.mentions.length > 0) {
    for (const handle of data.mentions.slice(0, 8)) {
      const uSnap = await db.doc(`usernames/${String(handle).toLowerCase()}`).get();
      if (uSnap.exists) {
        await createNotification({
          recipientId: uSnap.data().uid,
          actorId: data.authorId,
          type: 'mention',
          entityId: event.params.postId,
          previewText: data.caption || 'Mentioned you in a post',
        });
      }
    }
  }
});

exports.onPostDeleted = onDocumentDeleted('posts/{postId}', async (event) => {
  const data = event.data?.data();
  if (!data?.authorId) return;
  await db.doc(`users/${data.authorId}`).set({ postsCount: FieldValue.increment(-1) }, { merge: true });
});

// 2. Likes counter & notification
exports.onLikeCreated = onDocumentCreated('posts/{postId}/likes/{uid}', async (event) => {
  const { postId, uid } = event.params;
  const postRef = db.doc(`posts/${postId}`);
  await postRef.set({ likesCount: FieldValue.increment(1) }, { merge: true });
  const postSnap = await postRef.get();
  if (postSnap.exists) {
    await createNotification({
      recipientId: postSnap.data().authorId,
      actorId: uid,
      type: 'like',
      entityId: postId,
      previewText: postSnap.data().caption || 'Liked your post',
    });
  }
});

exports.onLikeDeleted = onDocumentDeleted('posts/{postId}/likes/{uid}', async (event) => {
  await db.doc(`posts/${event.params.postId}`).set({ likesCount: FieldValue.increment(-1) }, { merge: true });
});

// 3. Comments counter & notification (comments + replies)
exports.onCommentCreated = onDocumentCreated('posts/{postId}/comments/{commentId}', async (event) => {
  const { postId } = event.params;
  const data = event.data?.data();
  if (!data?.authorId) return;
  const postRef = db.doc(`posts/${postId}`);
  await postRef.set({ commentsCount: FieldValue.increment(1) }, { merge: true });
  const postSnap = await postRef.get();
  if (postSnap.exists) {
    await createNotification({
      recipientId: postSnap.data().authorId,
      actorId: data.authorId,
      type: data.parentCommentId ? 'reply' : 'comment',
      entityId: postId,
      previewText: data.text,
    });
  }
});

exports.onCommentDeleted = onDocumentDeleted('posts/{postId}/comments/{commentId}', async (event) => {
  await db.doc(`posts/${event.params.postId}`).set({ commentsCount: FieldValue.increment(-1) }, { merge: true });
});

// 4. Follower / Following counters & notifications
exports.onFollowCreated = onDocumentCreated('follows/{edgeId}', async (event) => {
  const data = event.data?.data();
  if (!data?.followerId || !data?.followingId) return;
  const batch = db.batch();
  batch.set(db.doc(`users/${data.followerId}`), { followingCount: FieldValue.increment(1) }, { merge: true });
  batch.set(db.doc(`users/${data.followingId}`), { followersCount: FieldValue.increment(1) }, { merge: true });
  await batch.commit();

  await createNotification({
    recipientId: data.followingId,
    actorId: data.followerId,
    type: 'follow',
    entityId: data.followerId,
    previewText: 'Started following you',
  });
});

exports.onFollowDeleted = onDocumentDeleted('follows/{edgeId}', async (event) => {
  const data = event.data?.data();
  if (!data?.followerId || !data?.followingId) return;
  const batch = db.batch();
  batch.set(db.doc(`users/${data.followerId}`), { followingCount: FieldValue.increment(-1) }, { merge: true });
  batch.set(db.doc(`users/${data.followingId}`), { followersCount: FieldValue.increment(-1) }, { merge: true });
  await batch.commit();
});

exports.onFollowRequestCreated = onDocumentCreated('followRequests/{reqId}', async (event) => {
  const data = event.data?.data();
  if (!data?.followerId || !data?.followingId) return;
  await createNotification({
    recipientId: data.followingId,
    actorId: data.followerId,
    type: 'follow_request',
    entityId: data.followerId,
    previewText: 'Requested to follow you',
  });
});

// 5. Story reaction notification
exports.onStoryReactionCreated = onDocumentCreated('stories/{storyId}/reactions/{uid}', async (event) => {
  const { storyId, uid } = event.params;
  const data = event.data?.data();
  const storySnap = await db.doc(`stories/${storyId}`).get();
  if (storySnap.exists) {
    await createNotification({
      recipientId: storySnap.data().authorId,
      actorId: uid,
      type: 'story_reaction',
      entityId: storyId,
      previewText: `Reacted ${data?.emoji || ''} to your story`,
    });
  }
});

// 6. Direct message notification
exports.onMessageCreated = onDocumentCreated('chats/{chatId}/messages/{messageId}', async (event) => {
  const { chatId } = event.params;
  const msg = event.data?.data();
  if (!msg?.senderId) return;
  const chatSnap = await db.doc(`chats/${chatId}`).get();
  if (!chatSnap.exists) return;
  const recipients = (chatSnap.data().members || []).filter((id) => id !== msg.senderId);
  for (const recipientId of recipients) {
    await createNotification({
      recipientId,
      actorId: msg.senderId,
      type: 'message',
      entityId: chatId,
      previewText: msg.text || (msg.media ? 'Sent media attachment' : 'New message'),
    });
  }
});

// 7. Scheduled 24-hour story cleanup (runs every hour)
exports.cleanupExpiredStories = onSchedule('every 60 minutes', async () => {
  const now = admin.firestore.Timestamp.now();
  const expired = await db.collection('stories').where('expiresAt', '<=', now).limit(200).get();
  const batch = db.batch();
  expired.docs.forEach((docSnap) => {
    const s = docSnap.data();
    if (s.publicId) {
      batch.set(db.collection('mediaDeletionQueue').doc(), {
        ownerId: s.authorId,
        publicId: s.publicId,
        resourceType: s.mediaType === 'video' ? 'video' : 'image',
        createdAt: FieldValue.serverTimestamp(),
      });
    }
    batch.delete(docSnap.ref);
  });
  if (!expired.empty) await batch.commit();
});

// 8. Signed Cloudinary Media Deletion Processor
exports.processCloudinaryDeletion = onDocumentCreated(
  {
    document: 'mediaDeletionQueue/{jobId}',
    secrets: [cloudinaryApiKey, cloudinaryApiSecret],
  },
  async (event) => {
    const data = event.data?.data();
    if (!data?.publicId) return;
    const timestamp = Math.floor(Date.now() / 1000);
    const signatureBase = `public_id=${data.publicId}&timestamp=${timestamp}${cloudinaryApiSecret.value()}`;
    const signature = crypto.createHash('sha1').update(signatureBase).digest('hex');

    const resourceType = data.resourceType === 'video' ? 'video' : 'image';
    const body = new URLSearchParams({
      public_id: data.publicId,
      timestamp: String(timestamp),
      api_key: cloudinaryApiKey.value(),
      signature,
    });

    await fetch(`https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/${resourceType}/destroy`, {
      method: 'POST',
      body,
    });

    await event.data.ref.delete();
  }
);
