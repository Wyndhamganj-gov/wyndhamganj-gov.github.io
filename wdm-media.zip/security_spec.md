# WDM Media — Security Specification & Dirty Dozen Audit

## 1. Core Data Invariants
1. **PII Isolation**: User email addresses reside exclusively in `users/{uid}/private/info` and are readable/writable only by `uid`. Public profiles (`users/{uid}`) contain zero PII.
2. **Immutable Server Counters**: Clients cannot create non-zero counters (`followersCount`, `followingCount`, `postsCount`, `likesCount`, `commentsCount`, `sharesCount`, `savesCount`) or modify counters on update.
3. **Strict Ownership & Identity Binding**: Every user-authored record (`posts`, `comments`, `stories`, `messages`, `likes`, `reports`, `mediaDeletionQueue`) binds `authorId`/`senderId`/`uid`/`reporterId` to `request.auth.uid`.
4. **Master Gate Subcollections**: Access to `chats/{chatId}/messages`, `posts/{postId}/likes`, `posts/{postId}/comments`, `stories/{storyId}/viewers`, and `stories/{storyId}/reactions` checks parent existence and membership/authorization via `get()`/`exists()` on single-document operations, while `list` queries enforce `resource.data` predicates with zero `get()` fan-out.
5. **Temporal & Schema Integrity**: `createdAt`/`updatedAt` must equal `request.time`; every string and array enforces explicit `.size()` bounds; every update uses action-partitioned `affectedKeys().hasOnly(...)` wrapped by `isValid[Entity](incoming())`.
6. **Backend-Only Notifications & Write-Only Reports**: Clients cannot create `notifications` or read `reports`/`mediaDeletionQueue`.

## 2. The Dirty Dozen Adversarial Payloads (All Must Return PERMISSION_DENIED)
1. **Shadow Field Injection on Profile Update**: Updating `users/{uid}` with `{ displayName: "Ok", isAdmin: true }` -> Blocked by `affectedKeys().hasOnly(...)` + `isValidUserProfile`.
2. **Counter Tampering on Post Update**: Updating `posts/{postId}` with `{ likesCount: 99999 }` -> Blocked by `affectedKeys().hasOnly(...)` + immutable counter check.
3. **PII Blanket Scrape**: Non-owner reading `users/{otherUid}/private/info` -> Blocked by `isOwner(uid)`.
4. **Identity Spoofing on Post Create**: Creating `posts/{id}` with `{ authorId: "victimUid", ... }` -> Blocked by `data.authorId == request.auth.uid`.
5. **Forged Notification Injection**: Client calling `addDoc(collection(db, 'notifications'), { recipientId: "victim", ... })` -> Blocked by `allow create: if false;`.
6. **Unauthorized Private Chat Read/List**: Non-member querying `chats/{chatId}` or `chats/{chatId}/messages` -> Blocked by `request.auth.uid in resource.data.members`.
7. **Unauthorized Private Account Post Access**: Non-follower fetching a `visibility: "followers"` post from another user -> Blocked by `isFollowing(...)` check.
8. **ID Poisoning Attack**: Creating a document with a 300-character or special-character document ID (`../../admin`) -> Blocked by `isValidId(id)`.
9. **Denial-of-Wallet Oversized String**: Creating a post with a 10,000-character caption or 50 hashtags -> Blocked by `caption.size() <= 2200` and `hashtags.size() <= 30`.
10. **Forged Timestamp Attack**: Creating a post with a backdated client timestamp `createdAt: Timestamp.fromMillis(0)` -> Blocked by `data.createdAt == request.time`.
11. **Report Enumeration Leak**: Authenticated user attempting `getDocs(collection(db, 'reports'))` -> Blocked by `allow read: if false;`.
12. **Self-Follow or Private Follow Bypass**: Creating `follows/{me_privateUser}` directly without an accepted follow request -> Blocked by `!(userDoc(followingId).data.isPrivate == true)`.
